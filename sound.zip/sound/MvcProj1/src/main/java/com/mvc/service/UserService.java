package com.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mvc.model.User;
import com.mvc.repository.UserEntity;
import com.mvc.repository.UserEntityRepository;

@Service("userService")
public class UserService{
	@Autowired	
	private UserEntityRepository userRepository;

    public void save(User user) {
       UserEntity entity = new UserEntity();
       entity.setMailId(user.getMailId());
       entity.setMobileNumber(user.getMobileNumber());
       entity.setPassword(user.getPassword());
       entity.setUserName(user.getUserName());
		userRepository.save(entity);
    	user.setUserName(user.getUserName()+" registerd");
    }

	

}
