package com.capg.lab2.service;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.lab2.model.Trainee;
import com.capg.lab2.repository.TraineeRepository;




@Service
public class TraineeService {
	@Autowired
	TraineeRepository repository;
	public void addTrainee(Trainee trainee) {
		repository.saveAndFlush(trainee);
    }
	
	
	  public void removeTrainee(int traineeId) { Optional<Trainee>
	  opt=repository.findById(traineeId); if(opt.isPresent()) { Trainee
	  trainee=opt.get(); repository.delete(trainee); } }
	  
	  public Trainee findTrainee(int traineeId){ 
		  Optional<Trainee>  opt=repository.findById(traineeId); 
		  if(opt.isPresent()) 
			  return opt.get();
	  return null; 
	  }
	  public Trainee updateTrainee(Trainee t) {
			return repository.save(t);
	  }

		public List<Trainee> getTrainee(){
			return repository.findAll();
			
		}

}
