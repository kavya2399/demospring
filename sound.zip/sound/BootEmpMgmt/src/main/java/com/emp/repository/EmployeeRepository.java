package com.emp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.emp.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	//@Query("select emp from Employee emp where emp.city = ?1")
    //Employee  findByCity(String city); 
}
