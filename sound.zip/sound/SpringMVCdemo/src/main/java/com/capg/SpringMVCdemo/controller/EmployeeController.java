package com.capg.SpringMVCdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capg.SpringMVCdemo.model.Employee;

@Controller
public class EmployeeController {
@RequestMapping("/addEmployee")
public ModelAndView getEmployeeHomePage() {
	ModelAndView mv=new ModelAndView();
	mv.setViewName("addEmployee");
	mv.addObject("emp",new Employee());
	return mv;
	
}
//@SuppressWarnings("unlikely-arg-type")
@RequestMapping(value="/add",method=RequestMethod.POST)
public ModelAndView addEmployee(@ModelAttribute("emp") Employee employee) {
	ModelAndView mv1=new ModelAndView();
	System.out.println(employee.getEmpId());
mv1.addObject("empName",employee.getEmpName());
	//mv1.addObject("emp",employee);
	mv1.setViewName("addemployeesuccess");
		/*
		 * if(employee.getEmpId().equals("admin") &&
		 * employee.getEmpName().equals("admin") && employee.getCity().equals("admin") )
		 * { mv1.setViewName("success"); } else { mv1.setViewName("failure"); }
		 */
	return mv1;
}
}
